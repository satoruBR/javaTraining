public interface Mediator {
    public abstract void createColleagues();
    public abstract void colleagueChanged();
}
